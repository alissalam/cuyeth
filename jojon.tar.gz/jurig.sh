@echo off
./xmrig --donate-level 1 -o de.qrl.herominers.com:1166 -u Q010500707aff80c954fe3809f5cd85584f2a2c3dc6f850c9517874cffc57df86d5edf8bacc1a17 -p GAS -a rx/0 -k 
pause